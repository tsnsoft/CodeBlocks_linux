/*
 */

#include <[SYSTEM_HDR]>

void main(void)
{

    // Insert code

    while(1)
        ;

}
