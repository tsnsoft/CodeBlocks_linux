/***************************************************************
 * Name:      [FILENAME_PREFIX]App.h
 * Purpose:   Defines Application Class
 * Author:    [AUTHOR_NAME] ([AUTHOR_EMAIL])
 * Created:   [NOW]
 * Copyright: [AUTHOR_NAME] ([AUTHOR_WWW])
 * License:
 **************************************************************/

#ifndef [PROJECT_HDR]APP_H
#define [PROJECT_HDR]APP_H

#include <wx/app.h>

class [CLASS_PREFIX]App : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // [PROJECT_HDR]APP_H
